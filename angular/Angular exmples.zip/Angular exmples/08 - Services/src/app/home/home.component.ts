import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { CategoriesService } from '../shared/services/categories.service';

@Component({
    selector: 'af-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit { 

    currentDate = new Date();
    discount = 10;
    categories: string[];

    // Declaring the needed services: 
    constructor(private titleService: Title, private categoriesService: CategoriesService) { }

    ngOnInit(): void {

        // Using the built-in service:
        this.titleService.setTitle("Northwind | Home");

        // Using our custom service: 
        this.categories = this.categoriesService.getCategories();
    }
}