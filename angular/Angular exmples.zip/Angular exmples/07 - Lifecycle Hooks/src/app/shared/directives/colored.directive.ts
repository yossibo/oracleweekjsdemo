import { Directive, ElementRef, Renderer2, Input, OnInit, HostListener } from '@angular/core';

// Custom Attribute Directive - Influancing on an existing element.

// @Directive is an annotation for declaring a directive.
@Directive({
    selector: "[afColored]"
})
export class ColoredDirective implements OnInit {

    // Default property (Usage: <someElement afColored="green" ... />):
    @Input("afColored") color: string;

    constructor(private elementRef: ElementRef, private renderer2: Renderer2) { }

    ngOnInit(): void {

        // Set random color if color undefined:
		if (!this.color) {
            this.color = this.getRandomColor();
        }

        // Paint fore color: 
        this.renderer2.setStyle(this.elementRef.nativeElement, "color", this.color);

        // Note: 
        // 1. Following line will work fine on web, but not on native mobile or deskop running Angular app.
        //    Thus we need to use Renderer2:
        //    elementRef.nativeElement.style.color = this.getRandomColor();
        // 2. Renderer2 is an Angular 4 upgrade of Renderer (performance wise).
        // 3. We can use more @Input variables and send values to them. E.g: 
        //    @Input() bg: string; // Usage: <someElement afColored bg="blue" ... />
        // 4. The color property can also be a set property.
        //    In that case, we don't need the ngOnInit because this code can be inside the set property.
	}

    // Events: 
    @HostListener("mouseenter") onMouseEnter() {
        this.renderer2.setStyle(this.elementRef.nativeElement, "color", "yellow");
    }
    @HostListener("mouseleave") onMouseLeave() {
        this.renderer2.setStyle(this.elementRef.nativeElement, "color", this.color);
    }

	// Get random color: 
    private getRandomColor(): string {
        let red = Math.floor(256 * Math.random());
        let green = Math.floor(256 * Math.random());
        let blue = Math.floor(256 * Math.random());
        let color = `rgb(${red},${green},${blue})`;
        return color;
    }
}