import { Directive, Input, TemplateRef, ViewContainerRef, OnInit } from '@angular/core';

// Structural Directive - influancing on the DOM (add or remove elements).

@Directive({
    selector: "[afSeason]"
})
export class SeasonDirective implements OnInit {

	// Default property (Usage: <someElement *afSeason="'summer'" ... />):
    @Input("afSeason") season: string;

    constructor(private templateRef: TemplateRef<any>, private viewContainerRef: ViewContainerRef) { }

    ngOnInit(): void {
        if (this.isSeason()) {
            this.viewContainerRef.createEmbeddedView(this.templateRef); // Create the template element inside the container.
        }
        else {
            this.viewContainerRef.clear(); // Clear the container, and thus the element won't be created.
        }
    }

    private isSeason(): boolean {
        let month = new Date().getMonth() + 1;
        switch(this.season) {
            case "spring": return month >= 4 && month <= 5;
            case "summer": return month >= 6 && month <= 9;
            case "autumn": return month >= 10 && month <= 11;
            case "winter": return month == 12 || month >=1 && month <= 3;
            default: return false; // No such season.
        }
    }
}