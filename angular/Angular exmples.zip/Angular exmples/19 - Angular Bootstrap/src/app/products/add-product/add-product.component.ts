import { Component } from "@angular/core";
import { FormGroup, FormBuilder, FormControl } from "@angular/forms";
import { Product } from "../../shared/models/product.model";

@Component({
    selector: 'af-add-product',
    templateUrl: './add-product.component.html',
    styleUrls: ['./add-product.component.css']
})
export class AddProductComponent {

    productForm: FormGroup;

    constructor(private formBuilder: FormBuilder) { 
        this.createForm();
    }

    private createForm(): void {
        this.productForm = this.formBuilder.group({
            productNameControl: ["", Product.productNameValidators],
            unitPriceControl: ["", Product.unitPriceValidators],
            unitsInStockControl: ["", Product.unitsInStockValidators],
            unitsOnOrderControl: ["", Product.unitsOnOrderValidators]
        });
    }

    addProduct(): void {
        let product = new Product();
        product.productName = this.productForm.get("productNameControl").value;
        product.unitPrice = this.productForm.get("unitPriceControl").value;
        product.unitsInStock = this.productForm.get("unitsInStockControl").value;
        product.unitsOnOrder = this.productForm.get("unitsOnOrderControl").value;
        alert("Adding the product: " + JSON.stringify(product));
    }
}