import { Component, OnInit } from '@angular/core';
import { Product } from '../../shared/models/product.model';
import { ProductsService } from '../../shared/services/products.service';
import { AsyncMathService } from '../../shared/services/async-math.service';

@Component({
    selector: 'af-product-list',
    templateUrl: './product-list.component.html',
    styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

    products: Product[];
    fontSize = 20;
    clickedImageSource: string;

    constructor(private productsService: ProductsService, private asyncMathService: AsyncMathService) { }

    ngOnInit() {
        this.productsService.getProducts().subscribe(products => this.products = products, error => alert(error.statusText));
    }

    showClickedImage(imageSource: string): void {
        this.clickedImageSource = imageSource;
    }

    showAveragePrice(): void {
        this.asyncMathService.getPriceAverage(this.products, avg => alert("Average Price: " + avg));
    }
}