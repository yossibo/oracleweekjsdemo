import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Product } from "../models/product.model";
import { Observable } from "rxjs/Observable";

@Injectable() // Needed because this service uses another injectable service.
export class ProductsService {

    constructor(private httpService: HttpClient) { }

    // 1. Using the native HttpClient async service:
    getProducts1(done: (products: Product[]) => void): void {
        this.httpService.get("/assets/api/products.json")
            .subscribe((response: Product[]) => done(response));
    }
    getProduct1(id: number, done: (product: Product) => void): void {
        this.httpService.get("/assets/api/products.json")
            .subscribe((response: Product[]) => done(response.find(p => p.productID == id)));
    }

    // 2. Using the HttpClient service with a Promise:
    getProducts2(): Promise<Product[]> {
        return new Promise((done: (products: Product[]) => void) => {
            this.httpService.get("/assets/api/products.json")
                .subscribe((response: Product[]) => done(response));
        });
    }
    getProduct2(id: number): Promise<Product> {
        return new Promise((done: (product: Product) => void) => {
            this.httpService.get("/assets/api/products.json")
                .subscribe((response: Product[]) => done(response.find(p => p.productID == id)));
        });
    }

    // 3. Using HttpClient service with the RxJS library:
    getProducts3(): Observable<Product[]> {
        return this.httpService.get("/assets/api/products.json")
            .map((response: Product[]) => response) // Convert response to Product[].
            .do(products => console.log(products)) // Do some other work with the data.
            .catch(error => Observable.throw(error)); // Throw on error (HttpErrorResponse object).
    }
    getProduct3(id: number): Observable<Product> {
        return this.httpService.get("/assets/api/products.json")
            .map((response: Product[]) => response.find(p => p.productID == id)) // Convert response to Product.
            .do(product => console.log(product)) // Do some other work with the data.
            .catch(error => Observable.throw(error)); // Throw on error (HttpErrorResponse object).
    }
}