import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from "@angular/common/http";
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { FooterComponent } from './footer/footer.component';
import { YearSlogenPipe } from './shared/pipes/year-slogen.pipe';
import { ColoredDirective } from './shared/directives/colored.directive';
import { SeasonDirective } from './shared/directives/season.directive';
import { CategoriesService } from './shared/services/categories.service';
import { ProductListComponent } from './products/product-list/product-list.component';
import { ProductsService } from './shared/services/products.service';
import { ProductImageComponent } from './products/product-image/product-image.component';
import { AppRoutingModule } from './app-routing.module';
import { RouterModule } from '@angular/router';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ProductDetailsComponent } from './products/product-details/product-details.component';
import "rxjs/Rx"; // Needed for the RxJS library.
import { AsyncMathService } from './shared/services/async-math.service';

@NgModule({

    imports: [
        BrowserModule,
        HttpClientModule, // Needed for the HttpClient.
        FormsModule,
        RouterModule,
        AppRoutingModule
    ],

    declarations: [
        AppComponent,
        HeaderComponent,
        HomeComponent,
        FooterComponent, 
        YearSlogenPipe,
        ColoredDirective,
        SeasonDirective,
        ProductListComponent,
        ProductImageComponent,
        PageNotFoundComponent,
        ProductDetailsComponent
    ],

    providers: [
        CategoriesService,
        ProductsService,
        AsyncMathService
    ],
    
    bootstrap: [AppComponent]
})
export class AppModule { }