import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Country } from '../models/country.model';

@Injectable()
export class CountriesService {

    constructor(private httpService: HttpClient) { }

    getUsers(callback: (countries: Country[]) => void): void {
        this.httpService.get("https://restcountries.eu/rest/v2/all")
            .subscribe((countries: Country[]) => callback(countries));
    }

}
