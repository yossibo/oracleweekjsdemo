import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { CountriesService } from './shared/services/countries.service';
import { CountryListComponent } from './country-list/country-list.component';
import { FormsModule } from "@angular/forms";

@NgModule({
    imports: [
        BrowserModule,
        RouterModule,
        HttpClientModule,
        AppRoutingModule,
        FormsModule
    ],
    declarations: [
        AppComponent,
        HeaderComponent,
        HomeComponent,
        PageNotFoundComponent,
        CountryListComponent
    ],
    providers: [
        CountriesService
    ],
    bootstrap: [
        AppComponent
    ]
})
export class AppModule { }
