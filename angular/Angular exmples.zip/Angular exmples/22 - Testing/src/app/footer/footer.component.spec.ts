import { ComponentFixture, async, TestBed, fakeAsync, tick } from "@angular/core/testing";
import { CommonModule } from "@angular/common";
import { FooterComponent } from "./footer.component";
import { YearSlogenPipe } from "../shared/pipes/year-slogen.pipe";
import { CategoriesService } from "../shared/services/categories.service";

// Create bunch of tests for FooterComponent (and more):
describe('FooterComponent (and more) Tests', () => {
    let component: FooterComponent;
    let fixture: ComponentFixture<FooterComponent>;

    // Do before each test - imports, declarations and provider needed:
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [CommonModule],
            declarations: [FooterComponent, YearSlogenPipe],
            providers: [CategoriesService]
        }).compileComponents();
    }));

    // Do before each test - create ProductListComponent instance:
    beforeEach(() => {
        fixture = TestBed.createComponent(FooterComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    // Create the tests - each will run independently of the others:

    // 1. Testing that the component has been created: 
    it('should be created', () => {
        expect(component).toBeTruthy();
    });

    // 2. Testing a data member value: 
    it('should contain 2017 in the currentYear Data-Member', () => {
        expect(component.currentYear).toEqual(2017);
    });

    // 3. Testing a html template value:
    it('should contain "All Rights Reserved" in a <p> element', () => {
        let html = fixture.debugElement.nativeElement;
        expect(html.querySelector("p").textContent).toContain("All Rights Reserved");
    });

    // 4. Testing a pipe:
    it('should contain "year"', () => {
        let yearSlogenPipe = new YearSlogenPipe();
        expect(yearSlogenPipe.transform("2017")).toContain("year");
    });

    // 5. Testing a sync service.
    it('should return a categories array of 8 items', () => {
        let categoriesService = fixture.debugElement.injector.get(CategoriesService); // Injecting the service.
        let categories = categoriesService.getCategories();
        expect(categories.length).toEqual(8);
    });
    
    // Note: To test an async service, there are several different techniques.
    // But documentations are complecated and most not working with Observables and RxJS.
    // Their examples work perfectly with non AJAX async services.
    // So, whoever want an example, should google it...

});