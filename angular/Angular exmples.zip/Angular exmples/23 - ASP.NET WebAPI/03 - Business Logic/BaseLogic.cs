﻿using System;

namespace IEC
{
    public class BaseLogic : IDisposable
    {
        // Entity Framework של Context-אובייקט ה
        // DB-זהו האובייקט שבעזרתו אנו ניגשים ל
        protected NorthwindEntities DB = new NorthwindEntities();

        public void Dispose()
        {
            DB.Dispose();
        }
    }
}
