﻿using System.Collections.Generic;
using System.Linq;

namespace IEC
{
    public class ProductsLogic : BaseLogic
    {
        public List<ProductModel> GetAllProducts()
        {
            // תאור שאילתה
            var query = from p in DB.Products
                        select new ProductModel
                        {
                            productID = p.ProductID,
                            productName = p.ProductName,
                            unitPrice = p.UnitPrice,
                            unitsInStock = p.UnitsInStock,
                            unitsOnOrder = p.UnitsOnOrder
                        };

            // והחזרת הנתונים DB-גישה ל
            return query.ToList();
        }

        public ProductModel GetOneProduct(int productID)
        {
            // תאור שאילתה
            var query = from p in DB.Products
                        where p.ProductID == productID
                        select new ProductModel
                        {
                            productID = p.ProductID,
                            productName = p.ProductName,
                            unitPrice = p.UnitPrice,
                            unitsInStock = p.UnitsInStock,
                            unitsOnOrder = p.UnitsOnOrder
                        };

            return query.SingleOrDefault();
        }

        public void AddNewProduct(ProductModel product)
        {
            Product p = new Product
            {
                ProductName = product.productName,
                UnitPrice = product.unitPrice,
                UnitsInStock = product.unitsInStock,
                UnitsOnOrder = product.unitsOnOrder
            };
            DB.Products.Add(p);
            DB.SaveChanges();
            product.productID = p.ProductID; // עדכון קוד המוצר החדש שמסד הנתונים יצר
        }
    }


    // שמות לא נכונים עבור מחלקה זו:
    // !שם לא נכון Product
    // !שם לא נכון Products
    // !שם לא נכון ProductLogic
    // !שם לא נכון Logic

}
