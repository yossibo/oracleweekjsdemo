import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { HomeComponent } from "./home/home.component";
import { ProductListComponent } from "./product-list/product-list.component";
import { PageNotFoundComponent } from "./page-not-found/page-not-found.component";
import { ProductDetailsComponent } from "./product-details/product-details.component";
import { AddProductComponent } from "./add-product/add-product.component";


// Defining of the different routes:
const appRoutes: Routes = [
    { path: "home", component: HomeComponent },
    { path: "products", component: ProductListComponent },
    { path: "products/new", component: AddProductComponent }, // הבא Route-חובה למקם לפני ה
    { path: "products/:id", component: ProductDetailsComponent},
    { path: "", redirectTo: "/home", pathMatch: "full"}, 
    { path: "**", component: PageNotFoundComponent }
];

@NgModule({
    imports: [RouterModule.forRoot(appRoutes)] 
})
export class AppRoutingModule {

}