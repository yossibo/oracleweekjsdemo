import { Component, OnInit, AfterViewInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit, AfterViewInit { // CTRL + .

  currentYear = new Date().getFullYear();

  constructor() { }

  // פונקציה המתבצעת פעם אחת לאחר אתחול הרכיב
  ngOnInit() {
  }

  // מאותחל View-פונקציה המתבצעת פעם אחת לאחר שה
  ngAfterViewInit(): void {
  }

}
