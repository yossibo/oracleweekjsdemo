export class Category { // יש להתחיל מחלקה באות גדולה לפי המוסכמות

    constructor(public categoryID: number, public categoryName: string) { }

    // כל משתנה וכל פונקציה - יש להתחיל באות קטנה לפי המוסכמות

}