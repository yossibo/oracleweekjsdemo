﻿using System.ComponentModel.DataAnnotations;

namespace IEC
{
    public class ProductModel
    {
        public int productID { get; set; }

        [Required(ErrorMessage = "Product name is required.")]
        [StringLength(40, ErrorMessage = "Length can't exceeds 40 chars.")]
        public string productName { get; set; }

        [Required(ErrorMessage = "Unit Price is required.")]
        public decimal? unitPrice { get; set; }

        public short? unitsInStock { get; set; }
        public short? unitsOnOrder { get; set; }
    }

    // Entity Framework למה לא להעביר ללקוח מחלקה של
    // 1. Entity Framework לפעמים אנו רוצים להוסיף מידע נוסף שלא קיים במחלקה של
    // 2. יכולות להכיל מידע שאנו לא רוצים להעביר ללקוח Entity Framework מחלקות של
    // 3. מכילות לרוב אובייקטים המתארים את הקישורים. אנו לא רוצים להחזיר אותם ללקוח Entity Framework מחלקות של
    // 4. לכן לא ניתן להעביר אותם בצורה פשוטה ללקוח Serializable האובייקטים שמתארים את הקישורים בין הטבלאות אינם
    // 5. חושפות שמות של מסד הנתונים - עמודות, טבלאות וכו'. אנו לא רוצים שהשמות הללו יגיעו ללקוח Entity Framework המחלקות של
    // 6. היא להתחיל באות גדולה. בצד הלקוח המוסכמה היא להתחיל באות קטנה Entity Framework המוסכמה של השמות של Naming Convention
}

