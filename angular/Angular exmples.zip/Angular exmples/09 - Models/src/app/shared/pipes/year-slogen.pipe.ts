import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name: "afYearSlogen"
})
export class YearSlogenPipe implements PipeTransform {

    transform(value: string): string {
        let arr = ["Good Year!", "Cool Year!", "Amazing Year!"];
        let index = Math.floor(Math.random() * arr.length);
        return value + " (" + arr[index] + ")";        
    }
}