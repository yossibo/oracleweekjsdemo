import { Product } from "../models/product.model";

export class AsyncMathService {

    getPriceAverage(products: Product[], callback: (avg: number) => void): void {
        setTimeout(() => {
            let sum = 0;
            products.forEach(p => sum += p.unitPrice);
            let avg = Math.round(sum / products.length * 100) / 100
            callback(avg);
        }, 3000);
    }
}