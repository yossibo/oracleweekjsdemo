import { NgModule, ModuleWithProviders } from "@angular/core";
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ProductListComponent } from './products/product-list/product-list.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

// Application Routes (order do important):
const appRoutes: Routes = [
    { path: 'home', component: HomeComponent },
    { path: 'products', component: ProductListComponent },
    { path: '', redirectTo: '/home', pathMatch: 'full' },
    { path: '**', component: PageNotFoundComponent },
];

// Application Router:
const appRouter: ModuleWithProviders = RouterModule.forRoot(appRoutes);

@NgModule({
    imports: [appRouter]
})
export class AppRoutingModule { }

// Note: 
// 1. For lazy loading a Module, do the following:
//    a. Create a dedicated Module containing all related components, e.g: AdminModule (say inside "./admin/admin.module").
//    b. Don't put any of that Module's Components in any other Module, inluding the AppModule, so those Components won't be loaded when other Modules are loaded.
//    c. Lazy Load that Module only when user surf to a related route, via following command, placed in the above Routes:
//       { path: "admin", loadChildren: "./admin/admin.module#AdminModule"}
// 2. For creating a Child routes (contains its own <router-outlet></router-outlet>), do the following:
//    a. { path: 'suppliers', component: SuppliersHomeComponent, children: [ 
//          { path: '', component: SupplierListComponent, children: [ // Will be relative to '/suppliers', thus will be: "/suppliers".
//              { path: '/retail', component: RetailSuppliersComponent }, // Will be relative to '/suppliers/', thus will be: "/suppliers/retail".
//              { path: '/wholesaler', component: WholesalerSuppliersComponent } // Will be relative to '/suppliers/', thus will be: "/suppliers/wholesaler". 
//          ]}
//       ]}
//    b. Place the <router-outlet></router-outlet> inside SuppliersHomeComponent's HTML.