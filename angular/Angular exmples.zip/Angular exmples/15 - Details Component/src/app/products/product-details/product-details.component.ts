import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ProductsService } from '../../shared/services/products.service';
import { Product } from '../../shared/models/product.model';

@Component({
    selector: 'af-product-details',
    templateUrl: './product-details.component.html',
    styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

    // Routed product:
    product: Product;

    // ActivatedRoute gives info about the current route, e.g. the route parameters.
    // Router can perform actions on the routing, e.g. go back:
    constructor(private productsService: ProductsService, 
        private route: ActivatedRoute, private router: Router) { }

    ngOnInit(): void {
        // Get product by product id sent to route params:
        this.route.params.subscribe(params => this.setProduct(params.id));
    }

    // Set product by product id:
    setProduct(id: number): void {
        this.product = this.productsService.getProduct(id);
    }

    goBack(): void {
        // Navigate back (with a better performance than the back button):
        this.router.navigate(["/products"]);    
        // The array is for building the final route. e.g: ["/a","b","1","c"] will navigate to: "/a/b/1/c".
    }
}