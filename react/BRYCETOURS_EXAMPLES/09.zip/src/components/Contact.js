import React, { Component } from 'react';

class Contact extends Component {
  render() {
    return (
      <div className="jumbotron  col-sm-12">
     <h1>Contact</h1>
      </div>
    );
  }
}

export default Contact;
