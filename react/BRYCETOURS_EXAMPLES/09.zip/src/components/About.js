import React, { Component } from 'react';

class About extends Component {
  render() {
    return (
      <div className="jumbotron  col-sm-12">
      <h1>about</h1>

      </div>
    );
  }
}

export default About;
